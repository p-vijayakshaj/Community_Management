# Community Management System

## Overview
The Community Management System is a full-stack web application developed to simplify the management of residential communities and apartment complexes. It provides a centralized platform for residents, tenants, administrators, security personnel, and facility managers to manage daily community operations efficiently.

## Features
- Resident Management
- Tenant Management
- User Authentication
- Complaint Registration and Tracking
- Maintenance Request Management
- Facility Booking
- Sports Court Booking
- Community Hall Booking
- Event Management
- Rental Management
- Café Management
- Security Dashboard
- Secretary/Admin Dashboard

## Technology Stack

Frontend:
- HTML5
- CSS3
- JavaScript

Backend:
- Node.js
- Express.js

Database:
- PostgreSQL

Architecture:
- Client-Server Architecture

## Installation

1. Clone the repository:
   git clone https://github.com/your-username/community-management-system.git

2. Navigate to the project folder:
   cd community-management-system/proj_dbms_ui

3. Install dependencies:
   npm install

4. Configure PostgreSQL with your database credentials.

5. Start the application:
   npm start

or

   npm run dev

The application will run at:
http://localhost:3000

## Modules
- Resident Management
- Tenant Management
- Complaint Management
- Maintenance Management
- Facility Booking
- Event Management
- Rental Management
- Café Management
- Security Dashboard
- Secretary/Admin Dashboard

## Objectives
- Digitize community administration.
- Reduce paperwork.
- Improve communication between residents and administrators.
- Automate complaint and maintenance management.
- Enable online facility booking.
- Provide secure access to community services.

## Future Enhancements
- Online Payment Gateway
- Email and SMS Notifications
- Visitor Management
- Mobile Application
- AI-based Complaint Analysis
- QR Code-based Visitor Entry
- Cloud Deployment

## Contributors
This project was developed as a collaborative academic project.

## License
This project is intended for educational and academic purposes only.
